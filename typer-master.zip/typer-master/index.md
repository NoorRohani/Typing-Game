# Typer

A tower defense like typing game. Characters can be case sensitive or insensitive. Wrong characters decrease the score. Click button to change case sensitivity. Pause by pressing _ESC_.

[![button](play.png)](typer.html)
